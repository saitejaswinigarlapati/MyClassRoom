import grpc
import calculator_pb2
import calculator_pb2_grpc

def run():
    channel = grpc.insecure_channel('localhost:50051')
    stub = calculator_pb2_grpc.CalculatorStub(channel)

    while True:
        print("\nMenu")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Exit")

        choice = int(input("Enter choice: "))

        if choice == 5:
            break

        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        request = calculator_pb2.CalcRequest(num1=num1, num2=num2)

        if choice == 1:
            response = stub.Add(request)
        elif choice == 2:
            response = stub.Subtract(request)
        elif choice == 3:
            response = stub.Multiply(request)
        elif choice == 4:
            response = stub.Divide(request)

        print("Result:", response.result)

if __name__ == "__main__":
    run()