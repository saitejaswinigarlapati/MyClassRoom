from concurrent import futures
import grpc
import calculator_pb2
import calculator_pb2_grpc

class Calculator(calculator_pb2_grpc.CalculatorServicer):

    def Add(self, request, context):
        return calculator_pb2.CalcReply(result=request.num1 + request.num2)

    def Subtract(self, request, context):
        return calculator_pb2.CalcReply(result=request.num1 - request.num2)

    def Multiply(self, request, context):
        return calculator_pb2.CalcReply(result=request.num1 * request.num2)

    def Divide(self, request, context):
        if request.num2 == 0:
            return calculator_pb2.CalcReply(result=0)
        return calculator_pb2.CalcReply(result=request.num1 / request.num2)

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    calculator_pb2_grpc.add_CalculatorServicer_to_server(Calculator(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Calculator server running on port 50051")
    server.wait_for_termination()

if __name__ == "__main__":
    serve()